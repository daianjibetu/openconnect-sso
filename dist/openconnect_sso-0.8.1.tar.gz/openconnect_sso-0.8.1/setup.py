# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['openconnect_sso', 'openconnect_sso.browser']

package_data = \
{'': ['*']}

install_requires = \
['PyQt6-WebEngine>=6.3.0,<7.0.0',
 'PyQt6>=6.3.0,<7.0.0',
 'PySocks>=1.7.1,<2.0.0',
 'attrs>=18.2',
 'colorama>=0.4,<0.5',
 'keyring>=21.1,<24.0.0',
 'lxml>=4.3,<5.0',
 'prompt-toolkit>=3.0.3,<4.0.0',
 'pyxdg>=0.26,<0.28',
 'requests>=2.22,<3.0',
 'setuptools>40.0',
 'structlog>=20.1',
 'toml>=0.10,<0.11']

extras_require = \
{':python_version < "3.8"': ['importlib-metadata>=3.10.0,<4.0.0']}

entry_points = \
{'console_scripts': ['openconnect-sso = openconnect_sso.cli:main']}

setup_kwargs = {
    'name': 'openconnect-sso',
    'version': '0.8.1',
    'description': 'Wrapper script for OpenConnect supporting Azure AD (SAMLv2) authentication to Cisco SSL-VPNs',
    'long_description': '# openconnect-sso\n\nこのプロジェクトは[vlaci/openconnect-sso](https://github.com/vlaci/openconnect-sso)からフォークされています。\n\nPyQt6対応済みです。\n必要の無いファイルは削除しました。\n\n\n\n### Build\n\nbuildをインストールします。\n\n```shell\n$ pip3 install build\n```\n\n`pyproject.toml`と同じディレクトリで以下を実行します。\n\n```shell\n$ python3 -m build\n```\n\ndist配下に`openconnect_sso-X.X.X-py3-none-any.whl`と`openconnect-sso-X.X.X.tar.gz`が生成されます。\n\n\n\n### Install\n\ndist配下で以下を実行します。\n\n```shell\n$ pip3 install openconnect_sso-X.X.X-py3-none-any.whl\n```\n\n\n### Usage\n\n[vlaci/openconnect-sso](https://github.com/vlaci/openconnect-sso)を参考にしてください。\n',
    'author': 'László Vaskó',
    'author_email': 'laszlo.vasko@outlook.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/vlaci/openconnect-sso',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'entry_points': entry_points,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
